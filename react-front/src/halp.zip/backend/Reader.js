const readClass = require("./build/Release/Reader.node");
// const r = require("./build/Release/Reader.node");
// export interface ReaderExport {
//   importFile: Function;
// }

// export var ReaderExport: {
//   new (arg: string): ReaderExport;
// } = r.ReaderExport;


const ree = (file) => {
  return readClass.importFile(file)
}

ree("/home/moop204/Documents/uni/thesis/OpenCellEd/react-front/src/backend/example/sample.xml");

export {
  ree
}