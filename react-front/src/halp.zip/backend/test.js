import { ree } from "./Reader.js";

ree(
  "/home/moop204/Documents/uni/thesis/OpenCellEd/react-front/src/backend/example/sample.xml"
);
